from data import db_session
from flask import Flask, render_template, url_for
from data.__all_models import *

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'


def main():
    db_session.global_init('db/blogs.db')
    app.run('127.0.0.1', port=8080)


@app.route('/')
def works_log():
    db_sess = db_session.create_session()
    jobs = db_sess.query(Jobs).all()
    # Подменяем id капитана на его имя во всех работах:
    for job in jobs:
        user = db_sess.query(User).filter(User.id == job.team_leader).first()
        job.team_leader = f'{user.surname} {user.name}'
    return render_template('jobs.html', base_css_directory=url_for('static', filename='css/style.css'),
                           jobs=jobs)


if __name__ == '__main__':
    main()
